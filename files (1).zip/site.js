(function(){
 var S=window.SITE||{},KEY='dv_consent';
 function get(){try{return localStorage.getItem(KEY)}catch(e){return null}}
 function set(v){try{localStorage.setItem(KEY,v)}catch(e){}}
 // подстановка данных сайта
 document.querySelectorAll('[data-site]').forEach(function(el){var v=S[el.dataset.site];if(v){el.textContent=v;if(el.tagName=='A'&&el.dataset.site=='email')el.href='mailto:'+v}});
 // реклама грузится только после согласия
 function ads(){
  if(!S.adsenseClient||window.__adsOn)return;window.__adsOn=1;
  var s=document.createElement('script');s.async=true;s.crossOrigin='anonymous';
  s.src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='+S.adsenseClient;document.head.appendChild(s);
  document.querySelectorAll('[data-ad]').forEach(function(el){var slot=S[el.dataset.ad];if(!slot)return;
   el.innerHTML='<ins class="adsbygoogle" style="display:block;min-height:90px" data-ad-client="'+S.adsenseClient+'" data-ad-slot="'+slot+'" data-ad-format="auto" data-full-width-responsive="true"></ins>';
   (window.adsbygoogle=window.adsbygoogle||[]).push({})});
 }
 function banner(){
  if(document.getElementById('cb'))return;
  var b=document.createElement('div');b.id='cb';b.setAttribute('role','dialog');b.setAttribute('aria-label','Cookie');
  b.innerHTML='<p>Мы используем cookie, чтобы сайт работал, а также (с вашего согласия) для показа рекламы и её персонализации. Подробнее — в <a href="/privacy">политике конфиденциальности</a>.</p><div><button class="ok" id="cy">Принять все</button><button id="cn">Только необходимые</button></div>';
  document.body.appendChild(b);
  document.getElementById('cy').onclick=function(){set('yes');b.remove();ads()};
  document.getElementById('cn').onclick=function(){set('no');b.remove()};
 }
 var c=get();if(c=='yes')ads();else if(c!='no')banner();
 var r=document.getElementById('cookie-settings');
 if(r)r.onclick=function(){set('');banner()};
})();
