// Dota Vault: сервер без зависимостей (Node 18+). Раздаёт сайт и API /api/inventory/:steamid
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000;
const PUB = __dirname; // все файлы лежат в одной папке
const ALLOWED = new Set(['index.html','about.html','guide.html','privacy.html','terms.html','contacts.html','site.css','site.js','config.js','ads.txt']);
const CACHE_FILE = path.join(__dirname, 'prices.json');
const HEADERS = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36', 'Accept-Language': 'en-US,en;q=0.9' };
const PRICE_TTL = 6 * 3600e3;   // цена актуальна 6 часов
const INV_TTL = 60e3;           // инвентарь кэшируется на 1 минуту
const PRICE_DELAY = 3500;       // Steam разрешает ~20 запросов цены в минуту
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const RANK = { Arcana: 0, Immortal: 1, Ancient: 2, Legendary: 3, Mythical: 4, Rare: 5, Uncommon: 6, Common: 7 };

const sleep = ms => new Promise(r => setTimeout(r, ms));
const httpErr = (status, message) => Object.assign(new Error(message), { status, message });

// ---------- цены ----------
let prices = {};
try { prices = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch {}
const queue = [], queued = new Set();
let working = false, sinceSave = 0;

const fresh = n => prices[n] && Date.now() - prices[n].t < PRICE_TTL;
function enqueue(name, rarity) {
  if (fresh(name) || queued.has(name)) return;
  queued.add(name);
  queue.push({ name, rank: RANK[rarity] ?? 9 });
  queue.sort((a, b) => a.rank - b.rank);   // сначала дорогие редкости
  work();
}
function parsePrice(s) { // "$1,234.56" -> 1234.56
  const n = parseFloat(String(s).replace(/,/g, '').replace(/[^\d.]/g, ''));
  return isNaN(n) ? 0 : n;
}
async function work() {
  if (working) return; working = true;
  while (queue.length) {
    const job = queue[0];
    try {
      const u = 'https://steamcommunity.com/market/priceoverview/?appid=570&currency=1&market_hash_name=' + encodeURIComponent(job.name);
      const r = await fetch(u, { headers: HEADERS });
      if (r.status === 429) { await sleep(60e3); continue; }  // лимит Steam: ждём и пробуем снова
      const j = r.ok ? await r.json() : {};
      const s = j.lowest_price || j.median_price;
      prices[job.name] = { p: s ? parsePrice(s) : 0, t: Date.now() };
    } catch { await sleep(5e3); continue; }
    queue.shift(); queued.delete(job.name);
    if (++sinceSave >= 10) { sinceSave = 0; save(); }
    await sleep(PRICE_DELAY);
  }
  save(); working = false;
}
function save() { try { fs.writeFileSync(CACHE_FILE, JSON.stringify(prices)); } catch {} }

// ---------- инвентарь ----------
const invCache = new Map();
async function loadInventory(id) {
  const hit = invCache.get(id);
  if (hit && Date.now() - hit.t < INV_TTL) return hit.items;
  const assets = [], descs = [];
  let start = '';
  for (let page = 0; page < 6; page++) {
    const u = `https://steamcommunity.com/inventory/${id}/570/2?l=english&count=2000` + (start ? `&start_assetid=${start}` : '');
    const r = await fetch(u, { headers: HEADERS });
    if (r.status === 403) throw httpErr(403, 'Инвентарь закрыт. Открой его в настройках приватности Steam.');
    if (r.status === 429) throw httpErr(429, 'Steam просит подождать. Попробуй через минуту.');
    if (r.status === 500 || r.status === 404) throw httpErr(404, 'Профиль не найден или инвентарь недоступен.');
    if (!r.ok) throw httpErr(502, 'Steam не ответил. Попробуй позже.');
    const j = await r.json();
    if (!j || !j.assets) break; // пустой инвентарь
    assets.push(...j.assets); descs.push(...j.descriptions);
    if (!j.more_items) break;
    start = j.last_assetid;
  }
  const dmap = new Map(descs.map(d => [d.classid + '_' + d.instanceid, d]));
  const grouped = new Map();
  for (const a of assets) {
    const d = dmap.get(a.classid + '_' + a.instanceid);
    if (!d) continue;
    const key = d.market_hash_name || d.name;
    const tag = c => (d.tags || []).find(t => t.category === c)?.localized_tag_name || '';
    const g = grouped.get(key) || {
      key, n: d.name, h: tag('Hero'), r: tag('Rarity') || 'Common',
      img: d.icon_url ? `https://community.cloudflare.steamstatic.com/economy/image/${d.icon_url}/256fx256f` : '',
      market: d.marketable === 1, q: 0
    };
    g.q += parseInt(a.amount || '1', 10);
    grouped.set(key, g);
  }
  const items = [...grouped.values()];
  invCache.set(id, { t: Date.now(), items });
  return items;
}
function withPrices(items) {
  let pending = 0;
  const out = items.map(i => {
    let p = 0;
    if (i.market) {
      if (fresh(i.key)) p = prices[i.key].p;
      else { p = prices[i.key] ? prices[i.key].p : null; pending++; enqueue(i.key, i.r); }
    }
    return { k: i.key, n: i.n, h: i.h, r: i.r, q: i.q, img: i.img, p, market: i.market };
  });
  return { items: out, pending: out.filter(i => i.p === null).length };
}

// ---------- защита от перегрузки ----------
const hits = new Map();
function limited(ip) {
  const now = Date.now(), a = (hits.get(ip) || []).filter(x => now - x < 60e3);
  a.push(now); hits.set(ip, a);
  return a.length > 40; // не больше 40 запросов в минуту с одного IP
}
setInterval(() => hits.clear(), 10 * 60e3).unref();
const PAGES = ['/', '/guide', '/about', '/privacy', '/terms', '/contacts'];

// ---------- сервер ----------
const send = (res, code, body, type = 'application/json; charset=utf-8') => {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': type.startsWith('text/html') || type.startsWith('application/json') ? 'no-store' : 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
};
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const m = url.pathname.match(/^\/api\/inventory\/(\d{17})$/);
  if (url.pathname === '/robots.txt' || url.pathname === '/sitemap.xml') {
    const base = 'https://' + (req.headers.host || 'localhost');
    return url.pathname === '/robots.txt'
      ? send(res, 200, `User-agent: *\nAllow: /\nSitemap: ${base}/sitemap.xml\n`, 'text/plain')
      : send(res, 200, '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + PAGES.map(p => `<url><loc>${base}${p}</loc></url>`).join('') + '</urlset>', 'application/xml');
  }
  if (m) {
    const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress).split(',')[0].trim();
    if (limited(ip)) return send(res, 429, { error: 'Слишком много запросов. Подожди минуту.' });
    try { send(res, 200, withPrices(await loadInventory(m[1]))); }
    catch (e) { send(res, e.status || 500, { error: e.message || 'Ошибка сервера' }); }
    return;
  }
  let rel = url.pathname === '/' ? '/index.html' : url.pathname;
  if (!path.extname(rel)) rel += '.html'; // /privacy -> privacy.html
  const file = path.join(PUB, rel);
  if (path.dirname(file) !== PUB || !ALLOWED.has(path.basename(file))) return send(res, 404, 'Not found', 'text/plain'); // серверные файлы наружу не отдаём
  fs.readFile(file, (err, data) => err
    ? send(res, 404, 'Not found', 'text/plain')
    : send(res, 200, data, MIME[path.extname(file)] || 'application/octet-stream'));
}).listen(PORT, () => console.log('Dota Vault: http://localhost:' + PORT));
